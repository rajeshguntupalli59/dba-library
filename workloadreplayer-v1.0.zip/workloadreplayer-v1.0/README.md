# WorkloadReplayer

**A free, self-hosted tool that replays your production database workload against staging — so you see what breaks before go-live.**

Capture the top queries from production (with their real timings), replay them against your staging database with configurable concurrency, and get a before/after report flagging every query that got slower or broke. 100% free, no signup, no license key.

## Demo

Watch the 20-second tour (the interactive demo on the website simulates a full capture → replay → report run):

<video src="https://rajeshguntupalli59.github.io/workload-replayer/demo.mp4" controls preload="metadata"></video>

---

## What it does

- **Capture** — reads the top-N queries by total time from `pg_stat_statements` (PostgreSQL) or `sys.dm_exec_query_stats` (SQL Server), saving each query with its production baseline timing
- **Replay** — executes the workload against a target database with configurable iterations (1–20) and concurrency (1–32 workers), timing every run and capturing errors with the database's own message
- **Compare** — per-query report: baseline vs replay mean, delta %, and status flags (OK / SLOWER ≥50% / FAILED / ERRORS / BLOCKED)
- **Safe mode** (on by default) — blocks INSERT/UPDATE/DELETE/DDL statements during replay so a workload captured from production can't write to your staging target unless you allow it
- **Engine guard** — refuses to replay a PostgreSQL workload against SQL Server and vice versa

## Supported databases

| Database | Versions | Capture source |
|---|---|---|
| PostgreSQL | 13, 14, 15, 16, 17 | `pg_stat_statements` (must be enabled) |
| Microsoft SQL Server | 2017, 2019, 2022, Express, Azure SQL | `sys.dm_exec_query_stats` (always on) |

---

## Installation

**1. Start the backend**
```bash
cd workload-replayer-v1.0/backend
pip install -r requirements.txt
uvicorn main:app --port 8003
```

**2. Open the app** — go to `http://localhost:8003` in your browser. The backend serves the UI itself; no separate frontend step.

> **PostgreSQL capture** needs the `pg_stat_statements` extension: `CREATE EXTENSION pg_stat_statements;` then restart Postgres with it in `shared_preload_libraries`.

## How to use it

1. **Connections** — add your production database (capture source) and your staging database (replay target). Test each with the Test button. Passwords are encrypted with Fernet before storage.
2. **Workloads** — pick the source connection, name the workload (e.g. `prod-morning-peak`), choose Top N, and Capture.
3. **Replay** — pick the workload and the target connection, set iterations/concurrency, keep safe mode on, and Run replay.
4. **Read the report** — green OK, orange SLOWER (≥50% regression), red FAILED (every run errored), BLOCKED (safe mode stopped a write). Expand any row's error to see the database message.

**Typical flow:** deploy your change to staging → replay the morning-peak workload → check the report → only promote to production when everything is green.

## Security

- **No cloud dependency.** Nothing leaves your machine.
- **No telemetry.** No usage data or analytics.
- **Credentials encrypted** with Fernet; key auto-generated at `data/.secret_key`.

## System requirements

| Requirement | Minimum |
|---|---|
| OS | Windows 10 / Server 2019, Ubuntu 20.04+, macOS 12+ |
| Python | 3.10+ |
| RAM | 1 GB |
| Disk | 200 MB |

For SQL Server connections, the machine running WorkloadReplayer needs the Microsoft ODBC Driver 17 or 18 for SQL Server.

## License

Free. Use it, share it, run it on as many servers as you like. Provided as-is with no warranty.

---

*WorkloadReplayer v1.0 — pairs with [QueryOptimizer](https://rajeshguntupalli59.github.io/query-optimizer/)*
