"""Open a DBAPI connection to PostgreSQL or SQL Server."""
import database


def open_connection(conn_row):
    """conn_row: sqlite Row (or dict) with db_type, host, port, database, username, password_enc."""
    db_type = conn_row["db_type"]
    password = database.dec_password(conn_row["password_enc"])
    if db_type == "postgres":
        import psycopg2
        host = conn_row["host"]
        kwargs = dict(
            dbname=conn_row["database"],
            user=conn_row["username"],
            password=password,
            connect_timeout=10,
            host=conn_row["host"],
            port=conn_row["port"],
        )
        conn = psycopg2.connect(**kwargs)
        conn.autocommit = True
        return conn
    if db_type == "mssql":
        import pyodbc
        drivers = [d for d in pyodbc.drivers() if "SQL Server" in d]
        if not drivers:
            raise RuntimeError("No SQL Server ODBC driver found. Install 'ODBC Driver 18 for SQL Server'.")
        server = conn_row["host"] if "\\" in conn_row["host"] else f"{conn_row['host']},{conn_row['port']}"
        auth = f"UID={conn_row['username']};PWD={password};" if conn_row["username"] else "Trusted_Connection=yes;"
        return pyodbc.connect(
            f"DRIVER={{{drivers[-1]}}};SERVER={server};DATABASE={conn_row['database']};"
            f"{auth}Connection Timeout=10;",
            autocommit=True,
        )
    raise ValueError(f"Unknown db_type: {db_type}")


def get_connection(conn_id: str):
    with database.db() as c:
        row = c.execute("SELECT * FROM connections WHERE id = ?", (conn_id,)).fetchone()
    if not row:
        raise ValueError("Connection not found")
    return row
