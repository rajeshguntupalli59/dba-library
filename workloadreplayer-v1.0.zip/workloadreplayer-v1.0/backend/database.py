"""SQLite store: connections (Fernet-encrypted passwords) + captured workloads."""
import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone

from cryptography.fernet import Fernet

DATA_DIR = os.environ.get("WR_DATA_DIR", os.path.join(os.path.dirname(__file__), "..", "data"))
KEY_PATH = os.path.join(DATA_DIR, ".secret_key")
DB_PATH = os.path.join(DATA_DIR, "workloadreplayer.db")


def _fernet() -> Fernet:
    os.makedirs(DATA_DIR, exist_ok=True)
    if os.path.exists(KEY_PATH):
        key = open(KEY_PATH, "rb").read().strip()
    else:
        key = Fernet.generate_key()
        with open(KEY_PATH, "wb") as f:
            f.write(key)
        os.chmod(KEY_PATH, 0o600)
    return Fernet(key)


_FERNET = None


def fernet() -> Fernet:
    global _FERNET
    if _FERNET is None:
        _FERNET = _fernet()
    return _FERNET


@contextmanager
def db():
    os.makedirs(DATA_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    with db() as c:
        c.execute("""
            CREATE TABLE IF NOT EXISTS connections (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                db_type TEXT NOT NULL,
                host TEXT NOT NULL,
                port INTEGER NOT NULL,
                database TEXT NOT NULL,
                username TEXT NOT NULL,
                password_enc TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        c.execute("""
            CREATE TABLE IF NOT EXISTS workloads (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                db_type TEXT NOT NULL,
                source_name TEXT NOT NULL,
                query_count INTEGER NOT NULL,
                captured_at TEXT NOT NULL,
                queries_json TEXT NOT NULL
            )
        """)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def new_id() -> str:
    return uuid.uuid4().hex[:12]


def enc_password(plain: str) -> str:
    return fernet().encrypt(plain.encode()).decode()


def dec_password(token: str) -> str:
    return fernet().decrypt(token.encode()).decode()
