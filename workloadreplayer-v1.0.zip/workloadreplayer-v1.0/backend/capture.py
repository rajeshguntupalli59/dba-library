"""Capture a workload: top-N queries by total time from the source database."""
import re

import database
import dbaccess

WRITE_KEYWORDS = re.compile(
    r"^\s*(INSERT|UPDATE|DELETE|MERGE|CREATE|ALTER|DROP|TRUNCATE|GRANT|REVOKE|EXEC|EXECUTE)\b",
    re.IGNORECASE,
)


def capture_pg(conn, limit: int) -> list[dict]:
    cur = conn.cursor()
    cur.execute(
        """
        SELECT query, calls, mean_exec_time, total_exec_time
        FROM pg_stat_statements
        WHERE query NOT ILIKE '%%pg_stat_statements%%'
          AND query NOT ILIKE '%%pg_stat_activity%%'
        ORDER BY total_exec_time DESC
        LIMIT %s
        """,
        (limit,),
    )
    rows = cur.fetchall()
    cur.close()
    return [
        {"sql": r[0].strip(), "calls": int(r[1]), "mean_ms": float(r[2] or 0),
         "total_ms": float(r[3] or 0)}
        for r in rows if r[0] and r[0].strip()
    ]


def capture_mssql(conn, limit: int) -> list[dict]:
    cur = conn.cursor()
    cur.execute(
        """
        SELECT TOP (?)
            SUBSTRING(qt.text, (qs.statement_start_offset/2)+1,
                ((CASE qs.statement_end_offset WHEN -1 THEN DATALENGTH(qt.text)
                  ELSE qs.statement_end_offset END - qs.statement_start_offset)/2)+1) AS sql_text,
            qs.execution_count,
            (qs.total_elapsed_time / 1000.0) / NULLIF(qs.execution_count, 0) AS mean_ms,
            qs.total_elapsed_time / 1000.0 AS total_ms
        FROM sys.dm_exec_query_stats qs
        CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) qt
        WHERE qt.text NOT LIKE '%%dm_exec_query_stats%%'
        ORDER BY qs.total_elapsed_time DESC
        """,
    )
    rows = cur.fetchall()
    cols = [d[0] for d in cur.description]
    cur.close()
    out = []
    for r in rows[:limit]:
        d = dict(zip(cols, r))
        sql = (d.get("sql_text") or "").strip()
        if not sql:
            continue
        out.append({"sql": sql, "calls": int(d.get("execution_count") or 0),
                    "mean_ms": float(d.get("mean_ms") or 0),
                    "total_ms": float(d.get("total_ms") or 0)})
    return out


def capture_workload(source_conn_id: str, name: str, limit: int = 50) -> dict:
    conn_row = dbaccess.get_connection(source_conn_id)
    conn = dbaccess.open_connection(conn_row)
    try:
        if conn_row["db_type"] == "postgres":
            queries = capture_pg(conn, limit)
        else:
            queries = capture_mssql(conn, limit)
    finally:
        conn.close()
    wid = database.new_id()
    import json
    with database.db() as c:
        c.execute(
            "INSERT INTO workloads (id, name, db_type, source_name, query_count, captured_at, queries_json)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (wid, name, conn_row["db_type"], conn_row["name"], len(queries),
             database.now_iso(), json.dumps(queries)),
        )
    return {"id": wid, "name": name, "db_type": conn_row["db_type"],
            "query_count": len(queries), "queries": queries}
