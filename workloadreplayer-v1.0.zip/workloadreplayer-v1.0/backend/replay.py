"""Replay a captured workload against a target database and compare with baseline."""
import re
import time
from concurrent.futures import ThreadPoolExecutor

import dbaccess
from capture import WRITE_KEYWORDS

WRITE_BLOCK_MSG = "blocked by safe mode (write/DDL statement)"


def _is_write(sql: str) -> bool:
    return bool(WRITE_KEYWORDS.match(sql))


def _run_once(conn_factory, sql: str) -> dict:
    """Run one statement, return {ms, error}."""
    conn = conn_factory()
    try:
        cur = conn.cursor()
        start = time.perf_counter()
        try:
            cur.execute(sql)
            # drain results so timing includes full execution
            try:
                while True:
                    if cur.description is None:
                        break
                    cur.fetchall()
                    if not cur.nextset():
                        break
            except Exception:
                pass
            ms = (time.perf_counter() - start) * 1000
            return {"ms": ms, "error": None}
        except Exception as e:  # noqa: BLE001
            ms = (time.perf_counter() - start) * 1000
            return {"ms": ms, "error": str(e)[:300]}
        finally:
            try:
                cur.close()
            except Exception:
                pass
    finally:
        try:
            conn.close()
        except Exception:
            pass


def replay_workload(workload: dict, target_conn_id: str, iterations: int = 3,
                    concurrency: int = 4, safe_mode: bool = True) -> dict:
    target_row = dbaccess.get_connection(target_conn_id)
    if target_row["db_type"] != workload["db_type"]:
        raise ValueError(
            f"Engine mismatch: workload captured from {workload['db_type']}, "
            f"target is {target_row['db_type']}"
        )

    queries = workload["queries"]
    tdict = dict(target_row)

    def conn_factory():
        return dbaccess.open_connection(tdict)

    # quick connectivity check
    _run_once(conn_factory, "SELECT 1")

    tasks = []
    for qi, q in enumerate(queries):
        for _ in range(max(1, iterations)):
            tasks.append((qi, q))

    def work(item):
        qi, q = item
        sql = q["sql"]
        if safe_mode and _is_write(sql):
            return qi, {"ms": 0.0, "error": WRITE_BLOCK_MSG, "blocked": True}
        r = _run_once(conn_factory, sql)
        r["blocked"] = False
        return qi, r

    per_query: dict[int, list] = {i: [] for i in range(len(queries))}
    with ThreadPoolExecutor(max_workers=max(1, min(concurrency, 32))) as ex:
        for qi, r in ex.map(work, tasks):
            per_query[qi].append(r)

    results = []
    for qi, q in enumerate(queries):
        runs = per_query[qi]
        ok = [r for r in runs if not r["error"]]
        errs = [r for r in runs if r["error"] and not r.get("blocked")]
        blocked = [r for r in runs if r.get("blocked")]
        ms_vals = [r["ms"] for r in ok]
        base = q.get("mean_ms") or 0
        mean = sum(ms_vals) / len(ms_vals) if ms_vals else 0.0
        if base > 0 and mean > 0:
            delta_pct = (mean - base) / base * 100
        else:
            delta_pct = None
        if errs and not ok:
            status = "failed"
        elif blocked and not ok:
            status = "blocked"
        elif delta_pct is not None and delta_pct >= 50:
            status = "slower"
        elif errs:
            status = "errors"
        else:
            status = "ok"
        results.append({
            "sql": q["sql"][:500],
            "baseline_mean_ms": round(base, 3),
            "baseline_calls": q.get("calls", 0),
            "runs": len(ok),
            "errors": len(errs),
            "blocked": len(blocked),
            "replay_mean_ms": round(mean, 3),
            "replay_min_ms": round(min(ms_vals), 3) if ms_vals else 0,
            "replay_max_ms": round(max(ms_vals), 3) if ms_vals else 0,
            "delta_pct": round(delta_pct, 1) if delta_pct is not None else None,
            "status": status,
            "first_error": errs[0]["error"] if errs else None,
        })

    summary = {
        "total": len(results),
        "ok": sum(1 for r in results if r["status"] == "ok"),
        "slower": sum(1 for r in results if r["status"] == "slower"),
        "failed": sum(1 for r in results if r["status"] == "failed"),
        "errors": sum(1 for r in results if r["status"] == "errors"),
        "blocked": sum(1 for r in results if r["status"] == "blocked"),
    }
    return {"summary": summary, "results": results,
            "target": target_row["name"], "iterations": iterations,
            "concurrency": concurrency, "safe_mode": safe_mode}
