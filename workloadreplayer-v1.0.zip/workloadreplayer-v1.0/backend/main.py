"""HTTP API: connections, workloads (capture), replay."""
import json

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import capture as capture_mod
import database
import dbaccess
import replay as replay_mod

app = FastAPI(title="WorkloadReplayer")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)

database.init_db()


# ---------------------------------------------------------------- models
class ConnectionIn(BaseModel):
    name: str
    db_type: str  # postgres | mssql
    host: str
    port: int
    database: str
    username: str = ""
    password: str = ""


class CaptureIn(BaseModel):
    source_connection_id: str
    name: str
    limit: int = 50


class ReplayIn(BaseModel):
    workload_id: str
    target_connection_id: str
    iterations: int = 3
    concurrency: int = 4
    safe_mode: bool = True


# ------------------------------------------------------------ connections
@app.get("/api/connections")
def list_connections():
    with database.db() as c:
        rows = c.execute(
            "SELECT id, name, db_type, host, port, database, username, created_at"
            " FROM connections ORDER BY created_at DESC").fetchall()
    return [dict(r) for r in rows]


@app.post("/api/connections")
def add_connection(body: ConnectionIn):
    if body.db_type not in ("postgres", "mssql"):
        raise HTTPException(400, "db_type must be postgres or mssql")
    cid = database.new_id()
    with database.db() as c:
        c.execute(
            "INSERT INTO connections (id, name, db_type, host, port, database, username, password_enc, created_at)"
            " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (cid, body.name, body.db_type, body.host, body.port, body.database,
             body.username, database.enc_password(body.password), database.now_iso()),
        )
    return {"id": cid}


@app.delete("/api/connections/{cid}")
def delete_connection(cid: str):
    with database.db() as c:
        c.execute("DELETE FROM connections WHERE id = ?", (cid,))
    return {"ok": True}


@app.post("/api/connections/{cid}/test")
def test_connection(cid: str):
    try:
        row = dbaccess.get_connection(cid)
        conn = dbaccess.open_connection(row)
        cur = conn.cursor()
        cur.execute("SELECT 1")
        cur.fetchone()
        cur.close()
        conn.close()
        return {"ok": True}
    except Exception as e:  # noqa: BLE001
        return {"ok": False, "error": str(e)[:300]}


# ------------------------------------------------------------- workloads
@app.get("/api/workloads")
def list_workloads():
    with database.db() as c:
        rows = c.execute(
            "SELECT id, name, db_type, source_name, query_count, captured_at"
            " FROM workloads ORDER BY captured_at DESC").fetchall()
    return [dict(r) for r in rows]


@app.get("/api/workloads/{wid}")
def get_workload(wid: str):
    with database.db() as c:
        row = c.execute("SELECT * FROM workloads WHERE id = ?", (wid,)).fetchone()
    if not row:
        raise HTTPException(404, "Workload not found")
    d = dict(row)
    d["queries"] = json.loads(d.pop("queries_json"))
    return d


@app.delete("/api/workloads/{wid}")
def delete_workload(wid: str):
    with database.db() as c:
        c.execute("DELETE FROM workloads WHERE id = ?", (wid,))
    return {"ok": True}


@app.post("/api/workloads/capture")
def capture_workload(body: CaptureIn):
    try:
        return capture_mod.capture_workload(body.source_connection_id, body.name,
                                            max(1, min(body.limit, 500)))
    except ValueError as e:
        raise HTTPException(404, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(500, f"Capture failed: {str(e)[:300]}")


# ---------------------------------------------------------------- replay
@app.post("/api/replay")
def replay(body: ReplayIn):
    with database.db() as c:
        row = c.execute("SELECT * FROM workloads WHERE id = ?", (body.workload_id,)).fetchone()
    if not row:
        raise HTTPException(404, "Workload not found")
    workload = dict(row)
    workload["queries"] = json.loads(workload.pop("queries_json"))
    try:
        return replay_mod.replay_workload(
            workload, body.target_connection_id,
            iterations=max(1, min(body.iterations, 20)),
            concurrency=max(1, min(body.concurrency, 32)),
            safe_mode=body.safe_mode,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:  # noqa: BLE001
        raise HTTPException(500, f"Replay failed: {str(e)[:300]}")


# ------------------------------------------------------- frontend static
import os  # noqa: E402

DIST = os.path.join(os.path.dirname(__file__), "static")
if os.path.isdir(DIST):
    app.mount("/", StaticFiles(directory=DIST, html=True), name="static")
