# WorkloadReplayer — User Guide

## 1. Concepts

- **Connection** — a saved database endpoint (production or staging). PostgreSQL or SQL Server.
- **Workload** — a named set of captured queries with their production baseline timings.
- **Replay** — executing a workload against a target database and comparing timings.

## 2. Setup

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --port 8003
```

Open `http://localhost:8003`.

### Enabling capture on PostgreSQL

`pg_stat_statements` must be installed and loaded:

```sql
CREATE EXTENSION pg_stat_statements;
```

And in `postgresql.conf`:
```
shared_preload_libraries = 'pg_stat_statements'
```
Restart PostgreSQL after changing it. SQL Server needs nothing — `sys.dm_exec_query_stats` is always available.

## 3. Connections

**Add:** name, type, host, port, database, username, password. For a local Unix-socket Postgres, put the socket directory in Host (e.g. `/var/run/postgresql`).

**Test:** verifies the credentials with a `SELECT 1` before you rely on the connection.

## 4. Capturing a workload

Workloads tab → pick the source connection → name it → Top N (1–500, default 50) → Capture.

What happens: the top-N queries by *total* execution time are read (slowest-first), excluding the monitoring queries themselves. Each stores SQL text, call count, mean ms, and total ms.

**Tip:** capture during your real peak window so the baseline reflects production reality.

## 5. Replaying

Replay tab → workload → target connection → options → Run replay.

| Option | Default | Notes |
|---|---|---|
| Iterations | 3 | Runs per query (1–20). More = steadier averages. |
| Concurrency | 4 | Parallel workers (1–32). Higher = more realistic load. |
| Safe mode | On | Blocks INSERT/UPDATE/DELETE/MERGE/DDL. Turn off only if you intend to write. |

The engine refuses engine-mismatched replays (PG workload → MSSQL target).

## 6. Reading the report

Summary cards count queries by status:

| Status | Meaning |
|---|---|
| OK | Ran clean, within 50% of baseline |
| SLOWER | Mean replay time ≥50% above baseline — investigate |
| FAILED | Every run errored (e.g. missing table after a migration) |
| ERRORS | Some runs errored |
| BLOCKED | Skipped by safe mode (write statement) |

Each row shows baseline ms, replay mean/min/max, delta %, run count, and the first error message when present.

**What to do with SLOWER:** check whether the plan changed on staging (missing index? stale statistics? different data volume?). Pair with QueryOptimizer's EXPLAIN visualizer.

**What to do with FAILED:** usually a schema drift between prod and staging — the query references something the migration didn't create.

## 7. Troubleshooting

**Capture returns 0 queries (PostgreSQL)** — `pg_stat_statements` isn't loaded. See section 2.

**"No SQL Server ODBC driver found"** — install Microsoft ODBC Driver 18 for SQL Server on the machine running the backend.

**Replay is slow** — lower iterations/concurrency, or narrow Top N. Each query runs `iterations` times.

**Connection refused on a Unix socket** — the Host must be the socket *directory*, and Port must match the server's port.

## 8. Files & data

- `data/workloadreplayer.db` — connections and workloads (SQLite)
- `data/.secret_key` — Fernet key for password encryption (keep private)
- `backend/static/` — built frontend (served by the backend)
